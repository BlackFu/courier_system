package com.yc.commons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbHelper {
	//加载驱动 类第一次使用时加载即可
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConn() throws SQLException{
		Connection conn = null;
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier_system?useUnicode=true&characterEncoding=utf8&useSSL=false","root","fjj19981028");
		return conn;
	}
	
	//关闭资源
	public void closeAll(ResultSet rs, PreparedStatement pstmt,Connection conn) {
		if(null != rs) {
			try {
				rs.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		if(null!=conn) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
