package com.yc.commons;

import java.sql.*;

public class DbUtil {
	public static void main(String[] args) throws SQLException {
		// 加载驱动
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier_system?useUnicode=true&characterEncoding=utf8&useSSL=false", "root", "fjj19981028");
		//System.out.println(conn.getClass().getName());

		String sql = "select * from user ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();

		while (rs.next()) {
			System.out.println(rs.getString("username") + "\t" + rs.getInt("password") + "\t" + rs.getInt("phone"));
		}

		// 关闭资源
		if (null != rs) {
			rs.close();
		}

		if (null != pstmt) {
			pstmt.close();
		}

		if (null != conn) {
			conn.close();
		}
	}
}
