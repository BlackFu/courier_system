package com.yc.entity;

public class UserInfoData {
	public String username;
	public String password;
	public int phone;

	public UserInfoData() {
	}
}