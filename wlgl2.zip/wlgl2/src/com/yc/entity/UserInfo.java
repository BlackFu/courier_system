package com.yc.entity;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UserInfo implements Serializable{
	//封装
	private String username;
	private String password;
	private int phone;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	
	@Override
	public String toString() {
		return "UserInfo [username=" + username + ", password=" + password + ", phone=" + phone +"]";
	}
	
}
