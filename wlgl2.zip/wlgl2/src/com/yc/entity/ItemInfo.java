package com.yc.entity;

public class ItemInfo {
	private int id;
	private String seName;
	private String sePhone;
	private String reName;
	private String reAdd;
	private String rePhone;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSeName() {
		return seName;
	}
	public void setSeName(String seName) {
		this.seName = seName;
	}
	public String getSePhone() {
		return sePhone;
	}
	public void setSePhone(String sePhone) {
		this.sePhone = sePhone;
	}
	public String getReName() {
		return reName;
	}
	public void setReName(String reName) {
		this.reName = reName;
	}
	public String getReAdd() {
		return reAdd;
	}
	public void setReAdd(String reAdd) {
		this.reAdd = reAdd;
	}
	public String getRePhone() {
		return rePhone;
	}
	public void setRePhone(String rePhone) {
		this.rePhone = rePhone;
	}
	@Override
	public String toString() {
		return "ItemInfo [id=" + id + ", seName=" + seName + ", sePhone=" + sePhone + ", reName=" + reName + ", reAdd="
				+ reAdd + ", rePhone=" + rePhone + "]";
	}
	
}
