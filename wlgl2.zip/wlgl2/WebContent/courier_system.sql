/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50513
Source Host           : localhost:3306
Source Database       : courier_system

Target Server Type    : MYSQL
Target Server Version : 50513
File Encoding         : 65001

Date: 2018-12-16 15:54:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for item
-- ----------------------------
DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `seName` varchar(50) DEFAULT NULL,
  `sePhone` varchar(50) DEFAULT NULL,
  `reName` varchar(50) DEFAULT NULL,
  `reAdd` varchar(50) DEFAULT NULL,
  `rePhone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of item
-- ----------------------------
INSERT INTO `item` VALUES ('320242', '蒋宇', '14773415865', '张茂松', '湖南衡阳湖南工学院', '1383838438');

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('admin', '123');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `phone` int(20) NOT NULL,
  PRIMARY KEY (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('蒋宇', '1', '1');
INSERT INTO `user` VALUES ('姜松', '123', '123');
INSERT INTO `user` VALUES ('木斯', '123', '1234567');
INSERT INTO `user` VALUES ('fu', '123', '123456789');
INSERT INTO `user` VALUES ('张', '123', '1234567890');
INSERT INTO `user` VALUES ('musy', '123', '1319344137');
